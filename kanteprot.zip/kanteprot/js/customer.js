// Customer Dashboard logic

document.addEventListener('DOMContentLoaded', function() {
  // Check authentication
  if (!requireAuth()) return;

  const user = getCurrentUser();
  if (!user) {
    window.location.href = 'index.html';
    return;
  }

  // Update welcome message
  const welcomeEl = document.getElementById('welcome');
  const userEmailEl = document.getElementById('userEmail');
  if (welcomeEl) welcomeEl.textContent = `Welcome, ${user.name}`;
  if (userEmailEl) userEmailEl.textContent = user.email;

  // Logout button
  const logoutBtn = document.getElementById('logoutBtn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', logout);
  }

  // Load dashboard data
  loadDashboard();

  // Loan form submission
  const loanForm = document.getElementById('loanForm');
  if (loanForm) {
    loanForm.addEventListener('submit', handleLoanApplication);
  }
});

// Load dashboard statistics
function loadDashboard() {
  const user = getCurrentUser();
  if (!user) return;

  const loans = getStorage(STORAGE_KEYS.LOANS) || [];
  const userLoans = loans.filter(loan => loan.customerId === user.id);

  // Calculate statistics
  const totalBorrowed = userLoans.reduce((sum, loan) => sum + loan.principal, 0);
  const activeLoans = userLoans.filter(loan => loan.status === 'active').length;
  const pendingLoans = userLoans.filter(loan => loan.status === 'pending').length;
  const overdueLoans = userLoans.filter(loan => {
    if (loan.status !== 'active') return false;
    const dueDate = new Date(loan.dueDate);
    return dueDate < new Date();
  }).length;

  // Update UI
  const totalBorrowedEl = document.getElementById('totalBorrowed');
  const activeLoansEl = document.getElementById('activeLoans');
  const pendingLoansEl = document.getElementById('pendingLoans');
  const overdueLoansEl = document.getElementById('overdueLoans');

  if (totalBorrowedEl) totalBorrowedEl.textContent = formatCurrency(totalBorrowed);
  if (activeLoansEl) activeLoansEl.textContent = activeLoans;
  if (pendingLoansEl) pendingLoansEl.textContent = pendingLoans;
  if (overdueLoansEl) overdueLoansEl.textContent = overdueLoans;

  // Load loan list
  loadLoanList(userLoans);
}

// Load loan list
function loadLoanList(loans) {
  const loanListEl = document.getElementById('loanList');
  if (!loanListEl) return;

  if (loans.length === 0) {
    loanListEl.innerHTML = '<p class="muted">No loans found. Apply for a loan above.</p>';
    return;
  }

  loanListEl.innerHTML = loans.map(loan => {
    const statusClass = loan.status === 'active' ? 'active' : loan.status === 'pending' ? 'pending' : 'overdue';
    const dueDate = loan.dueDate ? formatDate(loan.dueDate) : 'N/A';
    return `
      <div class="loan-item" style="padding:12px;margin-bottom:8px;background:rgba(255,255,255,0.05);border-radius:8px;">
        <div style="display:flex;justify-content:space-between;align-items:start">
          <div>
            <strong>${formatCurrency(loan.principal)}</strong>
            <div class="muted" style="font-size:12px;margin-top:4px">
              Status: <span class="${statusClass}">${loan.status}</span> | 
              Due: ${dueDate}
            </div>
            ${loan.purpose ? `<div style="font-size:12px;margin-top:4px">Purpose: ${loan.purpose}</div>` : ''}
          </div>
          <div style="text-align:right">
            <div style="font-size:14px;font-weight:600">${formatCurrency(loan.total)}</div>
            <div class="muted" style="font-size:11px">Total to repay</div>
          </div>
        </div>
      </div>
    `;
  }).join('');
}

// Handle loan application
function handleLoanApplication(e) {
  e.preventDefault();
  
  const user = getCurrentUser();
  if (!user) {
    window.location.href = 'index.html';
    return;
  }

  const amount = parseFloat(document.getElementById('loanAmount').value);
  const periodValue = document.getElementById('loanPeriod').value;
  const purpose = document.getElementById('loanPurpose').value;
  const collateral = document.getElementById('loanCollateral').value;

  if (!collateral) {
    showError('loanError', 'Collateral is required for loan approval');
    return;
  }

  const [days, interestRate] = periodValue.split('|').map(Number);
  const calculation = calculateLoan(amount, days, interestRate);

  // Show calculation result
  const calcResultEl = document.getElementById('calcResult');
  if (calcResultEl) {
    calcResultEl.style.display = 'block';
    calcResultEl.innerHTML = `
      <div style="padding:12px;background:rgba(255,255,255,0.05);border-radius:8px;">
        <strong>Loan Calculation:</strong>
        <div style="margin-top:8px;font-size:14px">
          <div>Principal: ${formatCurrency(calculation.principal)}</div>
          <div>Interest (${(interestRate * 100).toFixed(0)}%): ${formatCurrency(calculation.interest)}</div>
          <div style="margin-top:4px;font-weight:600">Total to repay: ${formatCurrency(calculation.total)}</div>
          <div style="font-size:12px;margin-top:4px">Daily payment: ${formatCurrency(calculation.dailyPayment)}</div>
        </div>
      </div>
    `;
  }

  // Create loan application
  const loans = getStorage(STORAGE_KEYS.LOANS) || [];
  const newLoan = {
    id: Date.now().toString(),
    customerId: user.id,
    customerName: user.name,
    customerEmail: user.email,
    principal: amount,
    interest: calculation.interest,
    total: calculation.total,
    days: days,
    interestRate: interestRate,
    purpose: purpose,
    collateral: collateral,
    status: 'pending',
    createdAt: new Date().toISOString(),
    dueDate: new Date(Date.now() + days * 24 * 60 * 60 * 1000).toISOString()
  };

  loans.push(newLoan);
  setStorage(STORAGE_KEYS.LOANS, loans);

  // Reset form
  document.getElementById('loanForm').reset();
  calcResultEl.style.display = 'none';

  // Reload dashboard
  loadDashboard();

  // Show success message
  showError('loanError', 'Loan application submitted successfully!');
  setTimeout(() => {
    const errorEl = document.getElementById('loanError');
    if (errorEl) {
      errorEl.style.display = 'none';
      errorEl.textContent = '';
    }
  }, 3000);
}

