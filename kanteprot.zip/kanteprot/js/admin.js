// Admin Dashboard logic

document.addEventListener('DOMContentLoaded', function() {
  // Check authentication
  if (!isAdminLoggedIn()) {
    window.location.href = 'index.html';
    return;
  }

  // Logout button
  const logoutBtn = document.getElementById('adminLogoutBtn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', logout);
  }

  // Load dashboard data
  loadAdminDashboard();

  // Walk-in form submission
  const walkinForm = document.getElementById('walkinForm');
  if (walkinForm) {
    walkinForm.addEventListener('submit', handleWalkinApplication);
  }

  // Show admin reminder section
  const adminReminderSection = document.getElementById('adminReminderSection');
  if (adminReminderSection) {
    adminReminderSection.style.display = 'block';
  }
});

// Load admin dashboard statistics
function loadAdminDashboard() {
  const customers = getStorage(STORAGE_KEYS.CUSTOMERS) || [];
  const loans = getStorage(STORAGE_KEYS.LOANS) || [];

  // Calculate statistics
  // Count registered customers
  const registeredCustomers = customers.length;
  
  // Count unique walk-in customers (those with customerId === null and unique names/phones)
  const walkInLoans = loans.filter(loan => loan.customerId === null);
  const uniqueWalkIns = new Set();
  walkInLoans.forEach(loan => {
    const identifier = loan.customerPhone || loan.customerEmail || loan.customerName;
    if (identifier) uniqueWalkIns.add(identifier);
  });
  const walkInCustomers = uniqueWalkIns.size;
  
  // Total customers = registered + unique walk-ins
  const totalCustomers = registeredCustomers + walkInCustomers;
  
  const pendingApprovals = loans.filter(loan => loan.status === 'pending').length;
  const activeLoans = loans.filter(loan => loan.status === 'active').length;
  const overdueLoans = loans.filter(loan => {
    if (loan.status !== 'active') return false;
    const dueDate = new Date(loan.dueDate);
    return dueDate < new Date();
  }).length;

  // Update UI
  const totalCustomersEl = document.getElementById('totalCustomers');
  const pendingApprovalsEl = document.getElementById('pendingApprovals');
  const activeLoansAdminEl = document.getElementById('activeLoansAdmin');
  const overdueLoansAdminEl = document.getElementById('overdueLoansAdmin');

  if (totalCustomersEl) totalCustomersEl.textContent = totalCustomers;
  if (pendingApprovalsEl) pendingApprovalsEl.textContent = pendingApprovals;
  if (activeLoansAdminEl) activeLoansAdminEl.textContent = activeLoans;
  if (overdueLoansAdminEl) overdueLoansAdminEl.textContent = overdueLoans;

  // Load pending applications
  loadPendingApplications(loans);

  // Load all loans
  loadAllLoans(loans);
}

// Load pending applications
function loadPendingApplications(loans) {
  const pendingArea = document.getElementById('pendingArea');
  if (!pendingArea) return;

  const pendingLoans = loans.filter(loan => loan.status === 'pending');

  if (pendingLoans.length === 0) {
    pendingArea.innerHTML = '<p class="muted">No pending applications.</p>';
    return;
  }

  pendingArea.innerHTML = pendingLoans.map(loan => {
    return `
      <div class="loan-item" style="padding:12px;margin-bottom:8px;background:rgba(255,255,255,0.05);border-radius:8px;">
        <div style="display:flex;justify-content:space-between;align-items:start">
          <div style="flex:1">
            <strong>${loan.customerName || 'Walk-in Customer'}</strong>
            <div class="muted" style="font-size:12px;margin-top:4px">
              ${loan.customerEmail || loan.customerPhone || 'No contact info'}
            </div>
            <div style="margin-top:8px">
              <div>Amount: <strong>${formatCurrency(loan.principal)}</strong></div>
              <div style="font-size:12px;margin-top:4px">
                Duration: ${loan.days} days | Interest: ${(loan.interestRate * 100).toFixed(0)}%
              </div>
              ${loan.purpose ? `<div style="font-size:12px;margin-top:4px">Purpose: ${loan.purpose}</div>` : ''}
              ${loan.collateral ? `<div style="font-size:12px;margin-top:4px">Collateral: ${loan.collateral}</div>` : ''}
            </div>
          </div>
          <div style="text-align:right;margin-left:16px">
            <div style="font-size:14px;font-weight:600">${formatCurrency(loan.total)}</div>
            <div class="muted" style="font-size:11px">Total to repay</div>
            <div style="margin-top:8px;display:flex;gap:8px">
              <button onclick="approveLoan('${loan.id}')" style="padding:6px 12px;font-size:12px;background:#28a745;border:none;border-radius:6px;cursor:pointer">Approve</button>
              <button onclick="rejectLoan('${loan.id}')" style="padding:6px 12px;font-size:12px;background:transparent;color:#ff6b6b;border:1px solid rgba(255,107,107,0.3);border-radius:6px;cursor:pointer">Reject</button>
            </div>
          </div>
        </div>
      </div>
    `;
  }).join('');
}

// Load all loans
function loadAllLoans(loans) {
  const allLoansArea = document.getElementById('allLoansArea');
  if (!allLoansArea) return;

  if (loans.length === 0) {
    allLoansArea.innerHTML = '<p class="muted">No loans found.</p>';
    return;
  }

  // Sort by date (newest first)
  const sortedLoans = [...loans].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  allLoansArea.innerHTML = sortedLoans.map(loan => {
    let statusClass = 'pending';
    if (loan.status === 'active') statusClass = 'active';
    else if (loan.status === 'paid') statusClass = 'paid';
    else if (loan.status === 'rejected') statusClass = 'rejected';
    
    const dueDate = loan.dueDate ? formatDate(loan.dueDate) : 'N/A';
    const paidDate = loan.paidDate ? formatDate(loan.paidDate) : null;
    const isOverdue = loan.status === 'active' && new Date(loan.dueDate) < new Date();
    
    return `
      <div class="loan-item" style="padding:12px;margin-bottom:8px;background:rgba(255,255,255,0.05);border-radius:8px;${isOverdue ? 'border-left:3px solid #ff6b6b' : loan.status === 'paid' ? 'border-left:3px solid #10b981' : ''}">
        <div style="display:flex;justify-content:space-between;align-items:start">
          <div style="flex:1">
            <strong>${loan.customerName || 'Walk-in Customer'}</strong>
            <div class="muted" style="font-size:12px;margin-top:4px">
              ${loan.customerEmail || loan.customerPhone || 'No contact info'}
            </div>
            <div style="margin-top:8px">
              <div>Amount: <strong>${formatCurrency(loan.principal)}</strong></div>
              <div style="font-size:12px;margin-top:4px">
                Status: <span class="${statusClass}">${loan.status}</span>
                ${loan.status === 'active' ? ` | Due: ${dueDate}${isOverdue ? ' <span style="color:#ff6b6b">(OVERDUE)</span>' : ''}` : ''}
                ${loan.status === 'paid' && paidDate ? ` | Paid: ${paidDate}` : ''}
              </div>
              ${loan.purpose ? `<div style="font-size:12px;margin-top:4px">Purpose: ${loan.purpose}</div>` : ''}
              ${loan.status === 'paid' ? `<div style="font-size:12px;margin-top:4px;color:var(--success)">✓ Revenue: ${formatCurrency(loan.interest)}</div>` : ''}
            </div>
          </div>
          <div style="text-align:right;margin-left:16px">
            <div style="font-size:14px;font-weight:600">${formatCurrency(loan.total)}</div>
            <div class="muted" style="font-size:11px">${loan.status === 'paid' ? 'Amount received' : 'Total to repay'}</div>
            ${loan.status === 'active' ? `<button onclick="markPaid('${loan.id}')" class="approve-btn" style="margin-top:8px;padding:6px 12px;font-size:12px;border:none;border-radius:6px;cursor:pointer">Mark Paid</button>` : ''}
          </div>
        </div>
      </div>
    `;
  }).join('');
}

// Approve loan
function approveLoan(loanId) {
  const loans = getStorage(STORAGE_KEYS.LOANS) || [];
  const loan = loans.find(l => l.id === loanId);
  
  if (loan) {
    loan.status = 'active';
    setStorage(STORAGE_KEYS.LOANS, loans);
    loadAdminDashboard();
  }
}

// Reject loan
function rejectLoan(loanId) {
  if (!confirm('Are you sure you want to reject this loan application?')) return;
  
  const loans = getStorage(STORAGE_KEYS.LOANS) || [];
  const loan = loans.find(l => l.id === loanId);
  
  if (loan) {
    loan.status = 'rejected';
    setStorage(STORAGE_KEYS.LOANS, loans);
    loadAdminDashboard();
  }
}

// Mark loan as paid
function markPaid(loanId) {
  if (!confirm('Mark this loan as paid? This will record the revenue.')) return;
  
  const loans = getStorage(STORAGE_KEYS.LOANS) || [];
  const loan = loans.find(l => l.id === loanId);
  
  if (loan && loan.status === 'active') {
    // Update loan status
    loan.status = 'paid';
    loan.paidDate = new Date().toISOString();
    loan.paidAmount = loan.total; // Record the total amount paid
    
    // Save updated loans
    setStorage(STORAGE_KEYS.LOANS, loans);
    
    // Show success message
    alert(`Loan marked as paid!\n\nRevenue recorded: ${formatCurrency(loan.interest)}\nTotal received: ${formatCurrency(loan.total)}`);
    
    // Reload dashboard to reflect changes
    loadAdminDashboard();
  } else if (loan && loan.status !== 'active') {
    alert('Only active loans can be marked as paid.');
  }
}

// Handle walk-in application
function handleWalkinApplication(e) {
  e.preventDefault();

  const name = document.getElementById('walkinName').value;
  const phone = document.getElementById('walkinPhone').value;
  const email = document.getElementById('walkinEmail').value;
  const amount = parseFloat(document.getElementById('walkinAmount').value);
  const periodValue = document.getElementById('walkinPeriod').value;
  const purpose = document.getElementById('walkinPurpose').value;
  const collateral = document.getElementById('walkinCollateral').value;

  const [days, interestRate] = periodValue.split('|').map(Number);
  const calculation = calculateLoan(amount, days, interestRate);

  // Create loan application
  const loans = getStorage(STORAGE_KEYS.LOANS) || [];
  const newLoan = {
    id: Date.now().toString(),
    customerId: null, // Walk-in customer
    customerName: name,
    customerPhone: phone,
    customerEmail: email || null,
    principal: amount,
    interest: calculation.interest,
    total: calculation.total,
    days: days,
    interestRate: interestRate,
    purpose: purpose,
    collateral: collateral,
    status: 'pending',
    createdAt: new Date().toISOString(),
    dueDate: new Date(Date.now() + days * 24 * 60 * 60 * 1000).toISOString()
  };

  loans.push(newLoan);
  setStorage(STORAGE_KEYS.LOANS, loans);

  // Reset form
  document.getElementById('walkinForm').reset();

  // Reload dashboard
  loadAdminDashboard();

  // Show success message
  showError('walkinError', 'Walk-in application created successfully!');
  setTimeout(() => {
    const errorEl = document.getElementById('walkinError');
    if (errorEl) {
      errorEl.style.display = 'none';
      errorEl.textContent = '';
    }
  }, 3000);
}

// Make functions globally available
window.approveLoan = approveLoan;
window.rejectLoan = rejectLoan;
window.markPaid = markPaid;

