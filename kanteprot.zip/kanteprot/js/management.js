// Business Management System - Admin Only

document.addEventListener('DOMContentLoaded', function() {
  // Check authentication - must be admin
  if (!isAdminLoggedIn()) {
    window.location.href = 'index.html';
    return;
  }

  // Logout button
  const logoutBtn = document.getElementById('managementLogoutBtn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', logout);
  }

  // Capital form submission
  const capitalForm = document.getElementById('capitalForm');
  if (capitalForm) {
    capitalForm.addEventListener('submit', handleCapitalUpdate);
  }

  // Load all management data
  loadManagementDashboard();
});

// Load management dashboard with all metrics
function loadManagementDashboard() {
  const loans = getStorage(STORAGE_KEYS.LOANS) || [];
  const customers = getStorage(STORAGE_KEYS.CUSTOMERS) || [];
  const capital = getStorage(STORAGE_KEYS.CAPITAL) || 0;
  const capitalHistory = getStorage(STORAGE_KEYS.CAPITAL_HISTORY) || [];

  // Calculate metrics
  const metrics = calculateBusinessMetrics(loans, customers, capital);

  // Update UI
  updateCapitalMetrics(metrics, capital);
  updateFinancialMetrics(metrics);
  updateLoanPortfolio(metrics);
  updateGrowthMetrics(metrics, customers);
  loadCapitalHistory(capitalHistory);
}

// Calculate all business metrics
function calculateBusinessMetrics(loans, customers, capital) {
  // Active loans
  const activeLoans = loans.filter(loan => loan.status === 'active');
  const paidLoans = loans.filter(loan => loan.status === 'paid');
  const defaultedLoans = loans.filter(loan => {
    if (loan.status !== 'active') return false;
    const dueDate = new Date(loan.dueDate);
    const daysOverdue = Math.floor((new Date() - dueDate) / (1000 * 60 * 60 * 24));
    return daysOverdue > 7; // Consider overdue more than 7 days as defaulted
  });

  // Financial calculations
  const totalLoansIssued = loans.length;
  const totalLoanVolume = loans.reduce((sum, loan) => sum + loan.principal, 0);
  const activeLoanValue = activeLoans.reduce((sum, loan) => sum + loan.principal, 0);
  const investedCapital = activeLoanValue; // Capital currently in active loans

  // Revenue calculations
  const totalRevenue = paidLoans.reduce((sum, loan) => sum + loan.interest, 0);
  const expectedRevenue = activeLoans.reduce((sum, loan) => sum + loan.interest, 0);
  const totalExpectedRevenue = totalRevenue + expectedRevenue;

  // Profit calculations
  const totalProfit = totalRevenue; // Profit is the interest earned
  const profitMargin = totalLoanVolume > 0 ? (totalRevenue / totalLoanVolume) * 100 : 0;

  // Capital metrics
  const availableCapital = capital - investedCapital;
  const capitalUtilization = capital > 0 ? (investedCapital / capital) * 100 : 0;

  // Growth metrics
  const avgLoanAmount = totalLoansIssued > 0 ? totalLoanVolume / totalLoansIssued : 0;
  const defaultRate = totalLoansIssued > 0 ? (defaultedLoans.length / totalLoansIssued) * 100 : 0;
  const recoveryRate = totalLoansIssued > 0 ? (paidLoans.length / totalLoansIssued) * 100 : 0;

  return {
    capital,
    availableCapital,
    investedCapital,
    capitalUtilization,
    totalRevenue,
    expectedRevenue,
    totalExpectedRevenue,
    totalProfit,
    profitMargin,
    totalLoansIssued,
    activeLoanValue,
    defaultedLoans: defaultedLoans.length,
    defaultRate,
    totalLoanVolume,
    avgLoanAmount,
    recoveryRate,
    activeLoans: activeLoans.length,
    paidLoans: paidLoans.length
  };
}

// Update capital metrics
function updateCapitalMetrics(metrics, capital) {
  const totalCapitalEl = document.getElementById('totalCapital');
  const availableCapitalEl = document.getElementById('availableCapital');
  const investedCapitalEl = document.getElementById('investedCapital');
  const capitalUtilizationEl = document.getElementById('capitalUtilization');

  if (totalCapitalEl) totalCapitalEl.textContent = formatCurrency(metrics.capital);
  if (availableCapitalEl) availableCapitalEl.textContent = formatCurrency(metrics.availableCapital);
  if (investedCapitalEl) investedCapitalEl.textContent = formatCurrency(metrics.investedCapital);
  if (capitalUtilizationEl) {
    capitalUtilizationEl.textContent = `${metrics.capitalUtilization.toFixed(1)}%`;
    // Color code based on utilization
    if (metrics.capitalUtilization > 90) {
      capitalUtilizationEl.style.color = 'var(--error)';
    } else if (metrics.capitalUtilization > 70) {
      capitalUtilizationEl.style.color = 'var(--warning)';
    } else {
      capitalUtilizationEl.style.color = 'var(--success)';
    }
  }
}

// Update financial performance metrics
function updateFinancialMetrics(metrics) {
  const totalRevenueEl = document.getElementById('totalRevenue');
  const expectedRevenueEl = document.getElementById('expectedRevenue');
  const totalProfitEl = document.getElementById('totalProfit');
  const profitMarginEl = document.getElementById('profitMargin');

  if (totalRevenueEl) totalRevenueEl.textContent = formatCurrency(metrics.totalRevenue);
  if (expectedRevenueEl) expectedRevenueEl.textContent = formatCurrency(metrics.expectedRevenue);
  if (totalProfitEl) {
    totalProfitEl.textContent = formatCurrency(metrics.totalProfit);
    totalProfitEl.style.color = metrics.totalProfit >= 0 ? 'var(--success)' : 'var(--error)';
  }
  if (profitMarginEl) {
    profitMarginEl.textContent = `${metrics.profitMargin.toFixed(1)}%`;
    profitMarginEl.style.color = metrics.profitMargin >= 20 ? 'var(--success)' : metrics.profitMargin >= 10 ? 'var(--warning)' : 'var(--error)';
  }
}

// Update loan portfolio metrics
function updateLoanPortfolio(metrics) {
  const totalLoansIssuedEl = document.getElementById('totalLoansIssued');
  const activeLoanValueEl = document.getElementById('activeLoanValue');
  const defaultedLoansEl = document.getElementById('defaultedLoans');
  const defaultRateEl = document.getElementById('defaultRate');

  if (totalLoansIssuedEl) totalLoansIssuedEl.textContent = metrics.totalLoansIssued;
  if (activeLoanValueEl) activeLoanValueEl.textContent = formatCurrency(metrics.activeLoanValue);
  if (defaultedLoansEl) {
    defaultedLoansEl.textContent = metrics.defaultedLoans;
    defaultedLoansEl.style.color = metrics.defaultedLoans > 0 ? 'var(--error)' : 'var(--success)';
  }
  if (defaultRateEl) {
    defaultRateEl.textContent = `${metrics.defaultRate.toFixed(1)}%`;
    defaultRateEl.style.color = metrics.defaultRate > 10 ? 'var(--error)' : metrics.defaultRate > 5 ? 'var(--warning)' : 'var(--success)';
  }
}

// Update growth metrics
function updateGrowthMetrics(metrics, customers) {
  const totalCustomersEl = document.getElementById('totalCustomers');
  const avgLoanAmountEl = document.getElementById('avgLoanAmount');
  const totalLoanVolumeEl = document.getElementById('totalLoanVolume');
  const recoveryRateEl = document.getElementById('recoveryRate');

  if (totalCustomersEl) totalCustomersEl.textContent = customers.length;
  if (avgLoanAmountEl) avgLoanAmountEl.textContent = formatCurrency(metrics.avgLoanAmount);
  if (totalLoanVolumeEl) totalLoanVolumeEl.textContent = formatCurrency(metrics.totalLoanVolume);
  if (recoveryRateEl) {
    recoveryRateEl.textContent = `${metrics.recoveryRate.toFixed(1)}%`;
    recoveryRateEl.style.color = metrics.recoveryRate >= 80 ? 'var(--success)' : metrics.recoveryRate >= 60 ? 'var(--warning)' : 'var(--error)';
  }
}

// Load capital history
function loadCapitalHistory(history) {
  const capitalHistoryEl = document.getElementById('capitalHistory');
  if (!capitalHistoryEl) return;

  if (history.length === 0) {
    capitalHistoryEl.innerHTML = '<p class="muted">No capital transactions yet.</p>';
    return;
  }

  // Sort by date (newest first)
  const sortedHistory = [...history].sort((a, b) => new Date(b.date) - new Date(a.date));

  capitalHistoryEl.innerHTML = `
    <div style="overflow-x:auto">
      <table style="width:100%;border-collapse:collapse">
        <thead>
          <tr style="border-bottom:1px solid var(--border)">
            <th style="text-align:left;padding:12px;font-size:13px;color:var(--text-muted);font-weight:600">Date</th>
            <th style="text-align:left;padding:12px;font-size:13px;color:var(--text-muted);font-weight:600">Amount</th>
            <th style="text-align:left;padding:12px;font-size:13px;color:var(--text-muted);font-weight:600">Type</th>
            <th style="text-align:left;padding:12px;font-size:13px;color:var(--text-muted);font-weight:600">Note</th>
          </tr>
        </thead>
        <tbody>
          ${sortedHistory.map(entry => `
            <tr style="border-bottom:1px solid var(--border-light)">
              <td style="padding:12px;font-size:13px">${formatDate(entry.date)}</td>
              <td style="padding:12px;font-size:13px;font-weight:600;color:${entry.type === 'add' ? 'var(--success)' : 'var(--error)'}">
                ${entry.type === 'add' ? '+' : '-'}${formatCurrency(entry.amount)}
              </td>
              <td style="padding:12px;font-size:13px">
                <span style="padding:4px 8px;border-radius:4px;background:${entry.type === 'add' ? 'var(--success-light)' : 'var(--error-light)'};color:${entry.type === 'add' ? 'var(--success)' : 'var(--error)'};font-size:11px;text-transform:uppercase">
                  ${entry.type === 'add' ? 'Added' : 'Withdrawn'}
                </span>
              </td>
              <td style="padding:12px;font-size:13px;color:var(--text-muted)">${entry.note || '-'}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    </div>
  `;
}

// Handle capital update
function handleCapitalUpdate(e) {
  e.preventDefault();

  const amount = parseFloat(document.getElementById('capitalAmount').value);
  const note = document.getElementById('capitalNote').value || 'Capital addition';

  if (amount <= 0) {
    showError('capitalError', 'Amount must be greater than 0');
    return;
  }

  // Get current capital
  let currentCapital = getStorage(STORAGE_KEYS.CAPITAL) || 0;
  let capitalHistory = getStorage(STORAGE_KEYS.CAPITAL_HISTORY) || [];

  // Add to capital
  currentCapital += amount;

  // Add to history
  capitalHistory.push({
    id: Date.now().toString(),
    date: new Date().toISOString(),
    amount: amount,
    type: 'add',
    note: note,
    previousCapital: currentCapital - amount,
    newCapital: currentCapital
  });

  // Save
  setStorage(STORAGE_KEYS.CAPITAL, currentCapital);
  setStorage(STORAGE_KEYS.CAPITAL_HISTORY, capitalHistory);

  // Reset form
  document.getElementById('capitalForm').reset();

  // Reload dashboard
  loadManagementDashboard();

  // Show success
  showError('capitalError', 'Capital added successfully!');
  setTimeout(() => {
    const errorEl = document.getElementById('capitalError');
    if (errorEl) {
      errorEl.style.display = 'none';
      errorEl.textContent = '';
    }
  }, 3000);
}

