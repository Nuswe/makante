// Shared utilities and functions for the Kante Microfinance app

// Storage keys
const STORAGE_KEYS = {
  CUSTOMERS: 'kante_customers',
  LOANS: 'kante_loans',
  CURRENT_USER: 'kante_current_user',
  CURRENT_ADMIN: 'kante_current_admin',
  CAPITAL: 'kante_capital',
  CAPITAL_HISTORY: 'kante_capital_history'
};

// Get data from localStorage
function getStorage(key) {
  try {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : null;
  } catch (e) {
    console.error('Error reading from localStorage:', e);
    return null;
  }
}

// Set data to localStorage
function setStorage(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch (e) {
    console.error('Error writing to localStorage:', e);
    return false;
  }
}

// Check if user is logged in
function isCustomerLoggedIn() {
  return getStorage(STORAGE_KEYS.CURRENT_USER) !== null;
}

// Check if admin is logged in
function isAdminLoggedIn() {
  return getStorage(STORAGE_KEYS.CURRENT_ADMIN) !== null;
}

// Get current user
function getCurrentUser() {
  return getStorage(STORAGE_KEYS.CURRENT_USER);
}

// Get current admin
function getCurrentAdmin() {
  return getStorage(STORAGE_KEYS.CURRENT_ADMIN);
}

// Logout
function logout() {
  localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
  localStorage.removeItem(STORAGE_KEYS.CURRENT_ADMIN);
  window.location.href = 'index.html';
}

// Redirect if not authenticated
function requireAuth(redirectTo = 'index.html') {
  if (!isCustomerLoggedIn() && !isAdminLoggedIn()) {
    window.location.href = redirectTo;
    return false;
  }
  return true;
}

// Show error message
function showError(elementId, message) {
  const errorEl = document.getElementById(elementId);
  if (errorEl) {
    errorEl.textContent = message;
    errorEl.style.display = 'block';
    setTimeout(() => {
      errorEl.style.display = 'none';
    }, 5000);
  }
}

// Format currency
function formatCurrency(amount) {
  return `MWK ${amount.toLocaleString()}`;
}

// Format date
function formatDate(dateString) {
  const date = new Date(dateString);
  return date.toLocaleDateString('en-US', { 
    year: 'numeric', 
    month: 'short', 
    day: 'numeric' 
  });
}

// Calculate loan details
function calculateLoan(amount, days, interestRate) {
  const interest = amount * interestRate;
  const total = amount + interest;
  return {
    principal: amount,
    interest: interest,
    total: total,
    dailyPayment: total / days
  };
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    STORAGE_KEYS,
    getStorage,
    setStorage,
    isCustomerLoggedIn,
    isAdminLoggedIn,
    getCurrentUser,
    getCurrentAdmin,
    logout,
    requireAuth,
    showError,
    formatCurrency,
    formatDate,
    calculateLoan
  };
}

