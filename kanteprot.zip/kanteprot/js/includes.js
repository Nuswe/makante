// Load HTML includes dynamically
async function loadInclude(elementId, filePath) {
  try {
    const response = await fetch(filePath);
    if (!response.ok) throw new Error(`Failed to load ${filePath}`);
    const html = await response.text();
    const element = document.getElementById(elementId);
    if (element) {
      element.innerHTML = html;
    }
  } catch (error) {
    console.error(`Error loading include ${filePath}:`, error);
  }
}

// Load includes when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
  // Load header if header-container exists
  if (document.getElementById('header-container')) {
    loadInclude('header-container', 'includes/header.html');
  }
  
  // Load sidebar if sidebar-container exists
  if (document.getElementById('sidebar-container')) {
    loadInclude('sidebar-container', 'includes/sidebar.html');
  }
});

