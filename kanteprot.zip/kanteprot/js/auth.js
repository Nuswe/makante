// Authentication logic for Kante Microfinance

// Initialize authentication page
document.addEventListener('DOMContentLoaded', function() {
  // Check if already logged in
  if (isCustomerLoggedIn()) {
    window.location.href = 'customer-dashboard.html';
    return;
  }
  if (isAdminLoggedIn()) {
    window.location.href = 'admin-dashboard.html';
    return;
  }

  // Tab switching
  const customerTab = document.getElementById('customerTab');
  const adminTab = document.getElementById('adminTab');
  const customerAuth = document.getElementById('customerAuth');
  const adminAuth = document.getElementById('adminAuth');

  if (customerTab && adminTab) {
    customerTab.addEventListener('click', () => {
      customerTab.classList.add('active');
      customerTab.setAttribute('aria-selected', 'true');
      adminTab.classList.remove('active');
      adminTab.setAttribute('aria-selected', 'false');
      customerAuth.style.display = 'block';
      adminAuth.style.display = 'none';
    });

    adminTab.addEventListener('click', () => {
      adminTab.classList.add('active');
      adminTab.setAttribute('aria-selected', 'true');
      customerTab.classList.remove('active');
      customerTab.setAttribute('aria-selected', 'false');
      adminAuth.style.display = 'block';
      customerAuth.style.display = 'none';
    });
  }

  // Login/Register tab switching
  const showLoginBtn = document.getElementById('showLoginBtn');
  const showRegisterBtn = document.getElementById('showRegisterBtn');
  const loginView = document.getElementById('loginView');
  const registerView = document.getElementById('registerView');

  if (showLoginBtn && showRegisterBtn) {
    showLoginBtn.addEventListener('click', () => {
      showLoginBtn.setAttribute('aria-selected', 'true');
      showRegisterBtn.setAttribute('aria-selected', 'false');
      loginView.style.display = 'block';
      registerView.style.display = 'none';
    });

    showRegisterBtn.addEventListener('click', () => {
      showRegisterBtn.setAttribute('aria-selected', 'true');
      showLoginBtn.setAttribute('aria-selected', 'false');
      registerView.style.display = 'block';
      loginView.style.display = 'none';
    });
  }

  // Customer Login
  const loginForm = document.getElementById('loginForm');
  if (loginForm) {
    loginForm.addEventListener('submit', handleCustomerLogin);
  }

  // Customer Register
  const registerForm = document.getElementById('registerForm');
  if (registerForm) {
    registerForm.addEventListener('submit', handleCustomerRegister);
  }

  // Admin Login
  const adminLoginForm = document.getElementById('adminLoginForm');
  if (adminLoginForm) {
    adminLoginForm.addEventListener('submit', handleAdminLogin);
  }
});

// Handle customer login
function handleCustomerLogin(e) {
  e.preventDefault();
  const email = document.getElementById('loginEmail').value;
  const password = document.getElementById('loginPassword').value;

  // Get customers from storage
  let customers = getStorage(STORAGE_KEYS.CUSTOMERS) || [];

  // Find customer
  const customer = customers.find(c => c.email === email && c.password === password);

  if (customer) {
    // Set current user
    setStorage(STORAGE_KEYS.CURRENT_USER, customer);
    window.location.href = 'customer-dashboard.html';
  } else {
    showError('loginError', 'Invalid email or password');
  }
}

// Handle customer registration
function handleCustomerRegister(e) {
  e.preventDefault();
  const name = document.getElementById('regName').value;
  const email = document.getElementById('regEmail').value;
  const phone = document.getElementById('regPhone').value;
  const password = document.getElementById('regPassword').value;

  // Get customers from storage
  let customers = getStorage(STORAGE_KEYS.CUSTOMERS) || [];

  // Check if email already exists
  if (customers.find(c => c.email === email)) {
    showError('registerError', 'Email already registered');
    return;
  }

  // Create new customer
  const newCustomer = {
    id: Date.now().toString(),
    name,
    email,
    phone,
    password,
    createdAt: new Date().toISOString()
  };

  customers.push(newCustomer);
  setStorage(STORAGE_KEYS.CUSTOMERS, customers);

  // Auto login
  setStorage(STORAGE_KEYS.CURRENT_USER, newCustomer);
  window.location.href = 'customer-dashboard.html';
}

// Handle admin login
function handleAdminLogin(e) {
  e.preventDefault();
  const email = document.getElementById('adminEmail').value;
  const password = document.getElementById('adminPassword').value;

  // Demo admin credentials
  if (email === 'admin@kante.com' && password === 'admin123') {
    setStorage(STORAGE_KEYS.CURRENT_ADMIN, { email, name: 'Admin' });
    window.location.href = 'admin-dashboard.html';
  } else {
    showError('adminError', 'Invalid admin credentials');
  }
}

