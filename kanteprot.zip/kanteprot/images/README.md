# Logo Image

Place your custom logo image here.

## File Requirements:
- **Filename**: `logo.png`
- **Recommended size**: 200x200px to 400x400px
- **Format**: PNG with transparent background (preferred) or JPG
- **Aspect ratio**: Square (1:1) works best

## Supported Formats:
- PNG (recommended - supports transparency)
- JPG/JPEG
- SVG (if you update the HTML to support it)

## Fallback:
If the logo image is not found, the system will automatically display "K" as a fallback.

## Usage:
The logo will automatically be used in the header. Make sure the file is named exactly `logo.png` and placed in this `images/` directory.

