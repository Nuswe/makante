# Kante Microfinance Application

A multi-page microfinance application with separate authentication, customer dashboard, and admin dashboard pages.

## Project Structure

```
kanteprot/
├── index.html                 # Login/Register page
├── customer-dashboard.html    # Customer dashboard
├── admin-dashboard.html       # Admin dashboard
├── css/
│   └── styles.css            # Main stylesheet
├── js/
│   ├── shared.js             # Shared utilities (localStorage, auth helpers)
│   ├── includes.js           # Dynamic HTML include loader
│   ├── auth.js               # Authentication logic
│   ├── customer.js           # Customer dashboard logic
│   └── admin.js              # Admin dashboard logic
└── includes/
    ├── header.html           # Reusable header component
    └── sidebar.html          # Reusable sidebar component
```

## Features

### Security Improvements
- **Separated pages**: Authentication, customer, and admin functionality are on separate pages
- **Separated JavaScript**: Each page has its own JavaScript file, reducing security risks
- **Authentication checks**: Each protected page verifies user authentication before loading
- **No inline scripts**: All JavaScript is in separate files

### Pages

1. **index.html** - Login/Register page
   - Customer login/registration
   - Admin login
   - Redirects authenticated users to appropriate dashboard

2. **customer-dashboard.html** - Customer dashboard
   - View loan statistics
   - Apply for new loans
   - View loan history
   - Requires customer authentication

3. **admin-dashboard.html** - Admin dashboard
   - View all customers and loans
   - Approve/reject loan applications
   - Create walk-in customer applications
   - Manage loan statuses
   - Requires admin authentication

### JavaScript Files

- **shared.js**: Common utilities (localStorage management, authentication helpers, formatting functions)
- **includes.js**: Dynamically loads header and sidebar components
- **auth.js**: Handles login, registration, and authentication flow
- **customer.js**: Customer dashboard functionality (loan applications, statistics)
- **admin.js**: Admin dashboard functionality (loan management, approvals)

### Components

- **includes/header.html**: Site header with logo and branding
- **includes/sidebar.html**: Sidebar with reminders and notifications

## Usage

1. Open `index.html` in a web browser
2. Register a new customer account or login
3. Use admin credentials (admin@kante.com / admin123) for admin access

## Data Storage

The application uses browser localStorage to store:
- Customer accounts
- Loan applications
- Current session information

**Note**: This is a demo application. For production, implement proper backend authentication and database storage.

## Browser Compatibility

Requires modern browsers with:
- ES6+ JavaScript support
- Fetch API support
- localStorage support

